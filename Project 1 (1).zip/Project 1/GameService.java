package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	//Singleton pattern implementation
	private static GameService instance = new GameService();
	
	//Private constructor to prevent instantiation from external classes
	private GameService() {
	}
	
	//Get the singleton instance of GameService
	//@return the singleton instance
	public static GameService getInstance() {
		return instance;
	}
	/*Singleton instance is a pattern that ensures a class has only one instance. its purpose is to control the 
	 * instantiation of a class. Making sure there is only one instance and providing a way to access said instane
	 * from any point in the application. Charecteristics: Single Instance, Private Constructor, Static Instance, Lazy Initialization
	 * Gloal Access Point, Thread Safety, Global State, and common use cases
	 */


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {
		
		// a local game instance
				Game game = null;
		
		//Iterator to look for existing game with same name
		Iterator<Game> iterator = games.iterator();
		while (iterator.hasNext()) {
			Game existingGame = iterator.next();
			if (existingGame.getName().equals(name)) {
				//if game found return the existing instance
				return existingGame;
			}
		}
		/*The iterator pattern provides a way to access the elements of an object without exposing its representation.
		 * My iterator pattern is used to traverse and access the games stored in the list without revealing the details of 
		 * the internal representation of the list. It also provides uniform access, an iterator interface for traversing the collection, 
		 * Has a concrete iterator, includes an iterable collection, its usage is employed to search for existing games,
		 * and it includes encapsulation by seperating concerns between the collection and its travesal.
		 */
		

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
